% for simultaneously powering k vectors and re-normalze them.
k = 30;
theta = normrnd(0,1, [k,k]);
theta = theta / norm(theta);

for round = 1:5
    eta = W * theta; 
    eta_new = zeros(Vocs,k);
    
    
    for l = 1:Docs
        cl = trainX(l,:)';
        for t = 1:k
            temp1 = cl*(eta(:,t)'*cl)*(eta(:,t)'*cl) + 2*(cl.* cl.* eta(:,t)) - 2*(eta(:,t)'*cl)*(cl .* eta(:,t)) - cl * (cl'*(eta(:,t) .* eta(:,t)));
            temp1 = temp1 / (sum(cl) * (sum(cl)-1) * (sum(cl)-2));

            temp2 = (eta(:,t)' * mu)*((eta(:,t)'* cl)*cl - (cl .* eta(:,t))) + ((eta(:,t)'*cl)*(mu'*cl)*cl - (eta(:,t)'*mu)*(cl .* eta(:,t))) + ((eta(:,t)'*cl)*(eta(:,t)'*cl)*mu - mu * (cl'*(eta(:,t) .* eta(:,t))));
            temp2 = -temp2 / (sum(cl) * (sum(cl)-1)) * (alpha_0)/(alpha_0+2);

            eta_new(:,t) = eta_new(:,t) + temp1 + temp2;
        end
    end
    
    eta_new = eta_new / Docs;
    for t = 1:k
        eta_new(:,t) = eta_new(:,t) + alpha_0^2/((alpha_0+1)*(alpha_0+2)) * (eta(:,t)'*mu)*(eta(:,t)'*mu)*mu;
    end
   
    theta_new = W' * eta_new;
    

    if (round == 5)
        Z = zeros(k,1);
        for t = 1:k
            Z(t) = 2 / ((alpha_0 + 2)*theta(:,t)'*theta_new(:,t));
        end
        break;
    end
    
    %n = norm(theta_new)
    %theta = theta_new / n;
    sum(theta_new.^2,1)
    [theta, ~ ] = qr(theta_new);
    
end

O = zeros(Vocs,k);
for t = 1:k
    O(:,t) = pinv(W)' * theta(:,t) / Z(t);
end

