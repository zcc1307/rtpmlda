load('data.mat')
[Docs, Vocs] = size(trainX);
alpha_0 = 0.1469;
k = 30;
k2 = 50;


V_abs = sum(trainX,2);
mu = mean(trainX ./ (V_abs * ones(1,Vocs)))';


% If we are going to write down Pairs matrix explicitly

V_abs_corr1 = V_abs.*(V_abs-1);
Pairs = full((((trainX ./ (V_abs_corr1 * ones(1,Vocs)))' * trainX) / Docs) ...
- (diag(sum(trainX ./ (V_abs_corr1 * ones(1,Vocs)), 1) ) / Docs)...
- (alpha_0/(alpha_0+1)* (mu * mu')));

V_abs_corr2 = V_abs_corr1.*(V_abs-2);

R = normrnd(0, 1, [Vocs k2]);
[U, S, V] = svd(Pairs * R);
U = U(:,1:k);
[U2, T, V2] = svd(U' * Pairs * U);
W = U * U2 * diag(sqrt(ones(k,1)./diag(T)));
ApproxI = W' * Pairs * W;


